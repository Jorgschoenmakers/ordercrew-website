(function () {
  'use strict';
  const form = document.getElementById('demo-login-form');
  const username = document.getElementById('username');
  const password = document.getElementById('password');
  const error = document.getElementById('login-error');
  const toggle = document.getElementById('toggle-password');
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    error.hidden = true;
    username.removeAttribute('aria-invalid');
    password.removeAttribute('aria-invalid');
    const result = window.OrderCrewDemoAccess.signIn(username.value, password.value);
    if (result.ok) {
      password.value = '';
      location.assign('demo.html#overzicht');
      return;
    }
    error.textContent = result.reason === 'storage'
      ? 'Je browser staat tijdelijke opslag niet toe. Sta websiteopslag toe en probeer opnieuw.'
      : 'Deze combinatie klopt niet. Controleer je gebruikersnaam en wachtwoord en probeer opnieuw.';
    error.hidden = false;
    if (result.reason === 'credentials') {
      username.setAttribute('aria-invalid', 'true');
      password.setAttribute('aria-invalid', 'true');
      password.focus();
    } else {
      error.focus();
    }
  });
  toggle.addEventListener('click', function () {
    const visible = password.type === 'password';
    password.type = visible ? 'text' : 'password';
    toggle.textContent = visible ? 'Verbergen' : 'Tonen';
    toggle.setAttribute('aria-label', visible ? 'Wachtwoord verbergen' : 'Wachtwoord tonen');
    toggle.setAttribute('aria-pressed', String(visible));
  });
  window.addEventListener('pageshow', function () { password.value = ''; });
})();
