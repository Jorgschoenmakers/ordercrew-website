'use strict';

const navigation = document.querySelector('#site-navigation');
const menuToggle = document.querySelector('.menu-toggle');
if (navigation && menuToggle) {
  const closeMenu = () => { menuToggle.setAttribute('aria-expanded', 'false'); navigation.classList.remove('is-open'); };
  menuToggle.addEventListener('click', () => {
    const open = menuToggle.getAttribute('aria-expanded') !== 'true';
    menuToggle.setAttribute('aria-expanded', String(open));
    navigation.classList.toggle('is-open', open);
  });
  navigation.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && navigation.classList.contains('is-open')) { closeMenu(); menuToggle.focus(); } });
  document.addEventListener('click', event => { if (!event.target.closest('.header-inner')) closeMenu(); });
}

const portionInput = document.querySelector('#portion-count');
if (portionInput) {
  const number = new Intl.NumberFormat('nl-NL', {maximumFractionDigits: 3});
  const format = value => number.format(value);
  const setText = (id, value) => { document.getElementById(id).textContent = value; };
  const update = raw => {
    const parsed = Number(raw);
    if (!Number.isFinite(parsed) || raw === '' || !Number.isInteger(parsed) || parsed < 1 || parsed > 200) {
      portionInput.setCustomValidity('Kies een heel aantal van 1 tot en met 200 porties.');
      return;
    }
    portionInput.setCustomValidity('');
    portionInput.value = String(parsed);
    const chicken = parsed * 0.18;
    const shortage = Math.max(0, chicken - 4);
    const packages = Math.max(0, Math.ceil((shortage - 1e-9) / 2));
    setText('recipe-portions', parsed + (parsed === 1 ? ' portie' : ' porties'));
    setText('mep-count', parsed + (parsed === 1 ? ' portie' : ' porties'));
    setText('qty-chicken', format(chicken) + ' kg');
    setText('qty-potato', format(parsed * 0.2) + ' kg');
    setText('qty-carrot', format(parsed * 0.1) + ' kg');
    setText('qty-oil', format(parsed * 0.015) + ' l');
    setText('order-chicken', format(packages * 2) + ' kg');
    setText('order-packages', packages === 0 ? 'voldoende op voorraad' : packages + (packages === 1 ? ' bak van 2 kg' : ' bakken van 2 kg'));
    setText('calculation-note', shortage > 0 ? format(chicken) + ' kg nodig − 4 kg op voorraad = ' + format(shortage) + ' kg tekort. Afgerond op ' + (packages === 1 ? 'een bak' : packages + ' bakken') + ' van 2 kg.' : format(chicken) + ' kg nodig en 4 kg op voorraad. Je hoeft voor dit gerecht geen kipfilet bij te bestellen.');
    document.querySelectorAll('[data-portions]').forEach(button => {
      const active = Number(button.dataset.portions) === parsed;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    });
    document.getElementById('portion-less').disabled = parsed <= 1;
    document.getElementById('portion-more').disabled = parsed >= 200;
  };
  portionInput.addEventListener('input', () => update(portionInput.value));
  portionInput.addEventListener('change', () => { update(portionInput.value); portionInput.reportValidity(); });
  document.getElementById('portion-less').addEventListener('click', () => update(Math.max(1, (Number(portionInput.value) || 1) - 1)));
  document.getElementById('portion-more').addEventListener('click', () => update(Math.min(200, (Number(portionInput.value) || 0) + 1)));
  document.querySelectorAll('[data-portions]').forEach(button => button.addEventListener('click', () => update(Number(button.dataset.portions))));
  update(32);
}
