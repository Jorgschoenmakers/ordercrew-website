(function () {
  'use strict';
  // Shared prototype access only. This is not server-side authentication.
  const accessKey = 'ordercrew-sites-demo-access-v1';
  const closeKey = 'ordercrew-sites-close-v1';
  function closeMarker() {
    try { return localStorage.getItem(closeKey) || ''; } catch (error) { return ''; }
  }
  function isOpen() {
    try {
      const entry = JSON.parse(sessionStorage.getItem(accessKey) || 'null');
      return !!entry && entry.version === 1 && entry.user === 'ordercrewdemo'
        && entry.closeMarker === closeMarker();
    } catch (error) { return false; }
  }
  function clear() {
    try { sessionStorage.removeItem(accessKey); } catch (error) {}
  }
  function signIn(username, password) {
    clear();
    if (String(username).trim().toLowerCase() !== 'ordercrewdemo' || password !== 'ordercrew2026') {
      return {ok:false, reason:'credentials'};
    }
    try {
      sessionStorage.setItem(accessKey, JSON.stringify({version:1, user:'ordercrewdemo', closeMarker:closeMarker()}));
      if (!isOpen()) throw new Error('Temporary storage unavailable');
      return {ok:true};
    } catch (error) {
      clear();
      return {ok:false, reason:'storage'};
    }
  }
  function requireDemo() {
    if (isOpen()) {
      document.documentElement.classList.remove('oc-demo-pending');
      return true;
    }
    document.documentElement.classList.add('oc-demo-pending');
    clear();
    location.replace('login.html');
    return false;
  }
  window.OrderCrewDemoAccess = Object.freeze({isOpen, signIn, clear, requireDemo});
})();
